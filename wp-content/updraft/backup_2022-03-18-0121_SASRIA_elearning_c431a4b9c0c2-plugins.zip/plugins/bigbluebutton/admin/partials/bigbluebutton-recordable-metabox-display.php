<label><?php esc_html_e( 'Recordable', 'bigbluebutton' ); ?>: <input name="bbb-room-recordable" type="checkbox" value="checked"
<?php if ( 'true' === $existing_value) { ?>
	checked
<?php } ?>></label>
